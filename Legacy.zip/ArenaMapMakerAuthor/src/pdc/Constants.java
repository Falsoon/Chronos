package pdc;
/**
 * Encapsulate all the constants
 */
public class Constants {
	public static int GRIDDISTANCE = 15;
}
