import javax.swing.JPanel;

public class AuthorPanel extends JPanel {
	public AuthorPanel() {
		

	}
}
